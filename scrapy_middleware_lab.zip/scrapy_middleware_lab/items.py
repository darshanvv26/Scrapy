import scrapy

class ScrapyMiddlewareLabItem(scrapy.Item):
    text = scrapy.Field()
    author = scrapy.Field()
