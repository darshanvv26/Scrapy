BOT_NAME = 'scrapy_middleware_lab'

SPIDER_MODULES = ['scrapy_middleware_lab.spiders']
NEWSPIDER_MODULE = 'scrapy_middleware_lab.spiders'

ROBOTSTXT_OBEY = True

# Enable custom middleware
DOWNLOADER_MIDDLEWARES = {
    'scrapy_middleware_lab.middlewares.RandomUserAgentMiddleware': 543,
    'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
}
